create function invoiceopentodate(p_c_invoice_id numeric, p_c_invoicepayschedule_id numeric, p_dateacct timestamp with time zone)
  returns numeric
language plpgsql
as $$
DECLARE
v_TotalOpenAmt   numeric := 0;
BEGIN
v_TotalOpenAmt := invoiceopentodate(p_c_invoice_id, p_c_invoicepayschedule_id, date(p_dateacct));
RETURN v_TotalOpenAmt;
END;
$$;

comment on function invoiceopentodate(numeric, numeric, timestamp with time zone)
is '@updated=2016-02-26 01:27:28.0
@uuid=0448d710-b382-bb84-43dc-bde5b749919f
';

