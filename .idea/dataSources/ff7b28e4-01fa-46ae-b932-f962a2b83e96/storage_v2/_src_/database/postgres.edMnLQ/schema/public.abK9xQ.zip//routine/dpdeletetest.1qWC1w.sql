create function dpdeletetest(p_idkey integer)
  returns SETOF void
language plpgsql
as $$
BEGIN
	delete from tb_maintable where id_key=p_idkey;
  END;
$$;

